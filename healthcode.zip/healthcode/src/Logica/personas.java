/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

/**
 *
 * @author camilovelandia
 */
public class personas{
    private String codigo;
    private String cita;
    private String medico;
    private String precio;
    private String fecha;
    private String hora;
    private String horario;
    private String cedula;
    public personas(String codigo,String cedula, String cita, String medico, String precio, String fecha, String hora, String horario ){
        this.codigo=codigo;
        this.cita=cita;
        this.medico=medico;
        this.precio=precio;
        this.fecha=fecha;
        this.hora=hora;
        this.horario=horario;
        this.cedula=cedula;
    }
    public void setCedula(String cedula){
        this.cedula=cedula;
    }
    public String getCedula(){
        return cedula;
    }
     public String getHora(){
        return hora;
    }
    
    public void setHora(String hora){
        this.hora=hora;
    }
    
     public String getHorario(){
        return horario;
    }
    
    public void setHorario(String horario){
        this.horario=horario;
    }
    public String getCodigo(){
        return codigo;
    }
    
    public void setCodigo(String codigo){
        this.codigo=codigo;
    }
    
    public String getCita(){
        return cita;
    }
    
    public void setCita(String cita){
        this.cita=cita;
    }
    public String getMedico(){
        return medico;
    }
    
    public void setMedico(String medico){
        this.medico=medico;
    }
    public String getPrecio(){
        return precio;
    }
    
    public void setPrecio(String precio){
        this.precio=precio;
    }
    public String getFecha(){
        return fecha;
    }
    
    public void setFecha(String fecha){
        this.fecha=fecha;
    }
}
