/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Presentacion;

import Logica.TextPrompt;
import Presentacion.citas_formulario;
import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import javax.swing.JOptionPane;


public class Registro extends javax.swing.JFrame {

  
    public Registro() {
        initComponents();
  
       aviso.setVisible(false);
       aviso2.setVisible(false);
       aviso3.setVisible(false);
       aviso4.setVisible(false);
       aviso5.setVisible(false);
       aviso6.setVisible(false);
       aviso7.setVisible(false);
       aviso8.setVisible(false);
       TextPrompt text1 = new TextPrompt("Ingrese los nombres", texto1);
       TextPrompt text2 = new TextPrompt("Ingrese los apellidos", texto2);
       TextPrompt text3 = new TextPrompt("Ingrese el email", texto3);
       TextPrompt text4 = new TextPrompt("Ingrese el número de telefono", texto4);
       TextPrompt text5 = new TextPrompt("Ingrese el número de identificación", texto5);
       TextPrompt text6 = new TextPrompt("Ingrese el lugar de nacimiento", texto6);
       //TextPrompt text7 = new TextPrompt("Ingrese la fecha de nacimiento", texto7);
       TextPrompt text8 = new TextPrompt("Ingrese la dirección de residencia", texto8);
       setIconImage(getIconImage());
       this.setLocationRelativeTo(null);
       this.setResizable(false);
    }
    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("imagenes/logo.png"));
        return retValue;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro().setVisible(true);
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator8 = new javax.swing.JSeparator();
        back = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        texto1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        texto2 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        texto3 = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        combo1 = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        combo2 = new javax.swing.JComboBox<>();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel8 = new javax.swing.JLabel();
        texto4 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        texto5 = new javax.swing.JTextField();
        jSeparator7 = new javax.swing.JSeparator();
        texto6 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        combo3 = new javax.swing.JComboBox<>();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        aviso = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        aviso2 = new javax.swing.JLabel();
        jSeparator12 = new javax.swing.JSeparator();
        aviso3 = new javax.swing.JLabel();
        aviso4 = new javax.swing.JLabel();
        aviso5 = new javax.swing.JLabel();
        aviso8 = new javax.swing.JLabel();
        aviso6 = new javax.swing.JLabel();
        aviso7 = new javax.swing.JLabel();
        calen = new com.toedter.calendar.JDateChooser();
        jLabel12 = new javax.swing.JLabel();
        jSeparator10 = new javax.swing.JSeparator();
        texto8 = new javax.swing.JTextField();
        jSeparator9 = new javax.swing.JSeparator();
        jSeparator13 = new javax.swing.JSeparator();
        jSeparator11 = new javax.swing.JSeparator();
        jLabel14 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        boton2 = new javax.swing.JButton();
        boton1 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        back.setBackground(new java.awt.Color(255, 255, 255));
        back.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("REGISTRO DE PACIENTES");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Nombres *");

        texto1.setBorder(null);
        texto1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                texto1MousePressed(evt);
            }
        });
        texto1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                texto1ActionPerformed(evt);
            }
        });
        texto1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                texto1KeyTyped(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Apellidos *");
        jLabel4.setToolTipText("");

        texto2.setBorder(null);
        texto2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                texto2MousePressed(evt);
            }
        });
        texto2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                texto2KeyTyped(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("Email ");

        texto3.setBorder(null);
        texto3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                texto3MousePressed(evt);
            }
        });
        texto3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                texto3KeyTyped(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("Tipo de sangre *");

        combo1.setBackground(new java.awt.Color(204, 204, 204));
        combo1.setForeground(new java.awt.Color(204, 204, 204));
        combo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "O+", "O-", "AB+", "AB-", "A+", "A-", "B+", "B-" }));
        combo1.setBorder(null);
        combo1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                combo1MousePressed(evt);
            }
        });
        combo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo1ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setText("Estado Civil *");

        combo2.setBackground(new java.awt.Color(204, 204, 204));
        combo2.setForeground(new java.awt.Color(204, 204, 204));
        combo2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "Soltero", "Casado", "Viudo", "Divorciado", "Unión libre" }));
        combo2.setBorder(null);
        combo2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                combo2MousePressed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setText("Número de teléfono *");

        texto4.setBorder(null);
        texto4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                texto4MousePressed(evt);
            }
        });
        texto4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                texto4KeyTyped(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("Número de identificación *");

        texto5.setBorder(null);
        texto5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                texto5MousePressed(evt);
            }
        });
        texto5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                texto5KeyTyped(evt);
            }
        });

        texto6.setBorder(null);
        texto6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                texto6MousePressed(evt);
            }
        });
        texto6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                texto6KeyTyped(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setText("Fecha de nacimiento *");
        jLabel11.setToolTipText("");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setText("Tipo de identificación *");

        combo3.setBackground(new java.awt.Color(204, 204, 204));
        combo3.setForeground(new java.awt.Color(204, 204, 204));
        combo3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "CC", "T.I", "PASAPORTE" }));
        combo3.setBorder(null);

        aviso.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        aviso.setForeground(new java.awt.Color(255, 0, 0));
        aviso.setText("*");

        aviso2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        aviso2.setForeground(new java.awt.Color(255, 0, 0));
        aviso2.setText("*");

        aviso3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        aviso3.setForeground(new java.awt.Color(255, 0, 0));
        aviso3.setText("*");

        aviso4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        aviso4.setForeground(new java.awt.Color(255, 0, 0));
        aviso4.setText("*");

        aviso5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        aviso5.setForeground(new java.awt.Color(255, 0, 0));
        aviso5.setText("*");

        aviso8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        aviso8.setForeground(new java.awt.Color(255, 0, 0));
        aviso8.setText("*");

        aviso6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        aviso6.setForeground(new java.awt.Color(255, 0, 0));
        aviso6.setText("*");

        aviso7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        aviso7.setForeground(new java.awt.Color(255, 51, 0));
        aviso7.setText("*");

        calen.setDateFormatString("yyyy/MM/dd HH: mm:ss");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setText("Dirección de residencia");

        texto8.setBorder(null);
        texto8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                texto8MousePressed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setText("Lugar de nacimiento");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(texto4, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(jLabel8)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(aviso3))
                                            .addComponent(combo1, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                                .addComponent(jLabel6)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(aviso6))
                                            .addComponent(jSeparator4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE)
                                            .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE))
                                        .addGap(12, 12, 12))
                                    .addComponent(jSeparator11, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(texto6, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jSeparator13, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 276, Short.MAX_VALUE)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                        .addGap(14, 14, 14)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jSeparator7, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(texto5, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(combo2, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jSeparator12, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jSeparator5, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(jLabel9)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(aviso4))
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel4)
                                                    .addComponent(texto2, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(0, 0, Short.MAX_VALUE))
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(jLabel13)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(aviso8))
                                            .addComponent(combo3, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(jLabel7)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(aviso7))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(aviso5))
                                            .addComponent(calen, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jSeparator9)))))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(texto3)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addComponent(jLabel3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(aviso))
                                            .addComponent(texto1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE))
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addGap(241, 241, 241)
                                .addComponent(jLabel15)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(aviso2)))
                        .addGap(31, 31, 31))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(texto8, javax.swing.GroupLayout.PREFERRED_SIZE, 567, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jSeparator10, javax.swing.GroupLayout.PREFERRED_SIZE, 524, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(aviso)
                            .addComponent(jLabel15)
                            .addComponent(aviso2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(texto1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(texto2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel13)
                    .addComponent(aviso8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(texto3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(combo3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7)
                                    .addComponent(aviso6)
                                    .addComponent(aviso7))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(combo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(combo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9)
                                    .addComponent(aviso3)
                                    .addComponent(aviso4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(texto4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(texto5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator13, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel11)
                                    .addComponent(aviso5)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                                .addComponent(jLabel14))))
                    .addComponent(jSeparator12, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(calen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(texto6, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSeparator11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(texto8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(jSeparator10, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        back.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 590, 470));

        jPanel4.setBackground(new java.awt.Color(0, 204, 255));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 280, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        back.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 0, 280, 500));

        boton2.setBackground(new java.awt.Color(255, 0, 0));
        boton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        boton2.setText("BORRAR");
        boton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boton2ActionPerformed(evt);
            }
        });
        back.add(boton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, -1, -1));

        boton1.setBackground(new java.awt.Color(0, 204, 255));
        boton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        boton1.setText("REGISTRAR");
        boton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boton1ActionPerformed(evt);
            }
        });
        back.add(boton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 470, -1, -1));

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("REGRESAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        back.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 470, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(back, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(back, javax.swing.GroupLayout.DEFAULT_SIZE, 501, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void boton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boton2ActionPerformed
        texto1.setText("");
        texto2.setText("");
        texto3.setText("");
        texto4.setText("");
        texto5.setText("");
        texto6.setText("");
        texto8.setText("");
        combo1.setSelectedIndex(0);
        combo2.setSelectedIndex(0);
        combo3.setSelectedIndex(0);
    }//GEN-LAST:event_boton2ActionPerformed

    private void boton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boton1ActionPerformed
        if (texto1.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, diligencia los campos obligatorios", "ERROR", JOptionPane.WARNING_MESSAGE);
            aviso.setVisible(true);
        } else if (texto2.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, diligencia los campos obligatorios", "ERROR", JOptionPane.WARNING_MESSAGE);
            aviso2.setVisible(true);
        } else if (texto4.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, diligencia los campos obligatorios", "ERROR", JOptionPane.WARNING_MESSAGE);
            aviso3.setVisible(true);
        } else if (texto5.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, diligencia los campos obligatorios", "ERROR", JOptionPane.WARNING_MESSAGE);
            aviso4.setVisible(true);
        }
else if(combo1.getSelectedIndex() == 0)
            {
            JOptionPane.showMessageDialog(null, "Por favor, diligencia los campos obligatorios", "ERROR", JOptionPane.WARNING_MESSAGE);
            aviso6.setVisible(true);
            }
else if(combo2.getSelectedIndex() == 0)
            {
            JOptionPane.showMessageDialog(null, "Por favor, diligencia los campos obligatorios", "ERROR", JOptionPane.WARNING_MESSAGE);
            aviso7.setVisible(true);
            }
else if(combo3.getSelectedIndex() == 0)
            {
            JOptionPane.showMessageDialog(null, "Por favor, diligencia los campos obligatorios", "ERROR", JOptionPane.WARNING_MESSAGE);
            aviso8.setVisible(true);
            }
 else {
    JOptionPane.showMessageDialog(null, "Datos diligenciados correctamente", "Aviso!:", JOptionPane.WARNING_MESSAGE);
    aviso.setVisible(false);
    aviso2.setVisible(false);
    aviso3.setVisible(false);
    aviso4.setVisible(false);
    aviso5.setVisible(false);
    aviso6.setVisible(false);
    aviso7.setVisible(false);
    aviso8.setVisible(false);
    SimpleDateFormat nuevof = new SimpleDateFormat("dd/MM/yyyy"); // cambiar el formato de el jCalendar
    
    Tabla.AddRowToJTable(new Object []{
    texto1.getText(),
    texto2.getText(),
    texto4.getText(),
    combo3.getSelectedItem(),
    texto5.getText(),
    combo1.getSelectedItem(),
    combo2.getSelectedItem(),
    nuevof.format(calen.getDate())
        
});
   
   this.setVisible(false);
}

    }//GEN-LAST:event_boton1ActionPerformed

    private void texto8MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_texto8MousePressed
        texto8.setForeground(Color.black);
    }//GEN-LAST:event_texto8MousePressed

    private void texto6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_texto6KeyTyped
         char d = evt.getKeyChar();
        if((d<'a' || d>'z') && (d<'A') | d>'Z' && d != ' ' ) evt.consume();
    }//GEN-LAST:event_texto6KeyTyped

    private void texto6MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_texto6MousePressed
        texto6.setForeground(Color.black);
    }//GEN-LAST:event_texto6MousePressed

    private void texto5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_texto5KeyTyped
        char s = evt.getKeyChar();
        if(s<'0' || s>'9') evt.consume();
    }//GEN-LAST:event_texto5KeyTyped

    private void texto5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_texto5MousePressed
        texto5.setForeground(Color.black);
    }//GEN-LAST:event_texto5MousePressed

    private void texto4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_texto4KeyTyped
        char s = evt.getKeyChar();
        if(s<'0' || s>'9') evt.consume();
    }//GEN-LAST:event_texto4KeyTyped

    private void texto4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_texto4MousePressed
        texto4.setForeground(Color.black);
    }//GEN-LAST:event_texto4MousePressed

    private void combo2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_combo2MousePressed
        combo2.setForeground(Color.black);
    }//GEN-LAST:event_combo2MousePressed

    private void combo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_combo1ActionPerformed

    private void combo1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_combo1MousePressed
        combo1.setForeground(Color.black);
    }//GEN-LAST:event_combo1MousePressed

    private void texto3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_texto3KeyTyped

    }//GEN-LAST:event_texto3KeyTyped

    private void texto3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_texto3MousePressed
        texto3.setForeground(Color.black);
    }//GEN-LAST:event_texto3MousePressed

    private void texto2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_texto2KeyTyped
         char d = evt.getKeyChar();
        if((d<'a' || d>'z') && (d<'A') | d>'Z' && d != ' ' ) evt.consume();
    }//GEN-LAST:event_texto2KeyTyped

    private void texto2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_texto2MousePressed
        texto2.setForeground(Color.black);
    }//GEN-LAST:event_texto2MousePressed

    private void texto1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_texto1KeyTyped
        char d = evt.getKeyChar();
        if((d<'a' || d>'z') && (d<'A') | d>'Z' && d != ' ' ) evt.consume();
    }//GEN-LAST:event_texto1KeyTyped

    private void texto1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_texto1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_texto1ActionPerformed

    private void texto1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_texto1MousePressed
        texto1.setForeground(Color.black);

    }//GEN-LAST:event_texto1MousePressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);

    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel aviso;
    private javax.swing.JLabel aviso2;
    private javax.swing.JLabel aviso3;
    private javax.swing.JLabel aviso4;
    private javax.swing.JLabel aviso5;
    private javax.swing.JLabel aviso6;
    private javax.swing.JLabel aviso7;
    private javax.swing.JLabel aviso8;
    private javax.swing.JPanel back;
    private javax.swing.JButton boton1;
    private javax.swing.JButton boton2;
    private com.toedter.calendar.JDateChooser calen;
    private javax.swing.JComboBox<String> combo1;
    private javax.swing.JComboBox<String> combo2;
    private javax.swing.JComboBox<String> combo3;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTextField texto1;
    private javax.swing.JTextField texto2;
    private javax.swing.JTextField texto3;
    private javax.swing.JTextField texto4;
    private javax.swing.JTextField texto5;
    private javax.swing.JTextField texto6;
    private javax.swing.JTextField texto8;
    // End of variables declaration//GEN-END:variables
}
